import streamlit as st
import pandas as pd
from backend.preprocessing import load_data, feature_engineering, get_season
from backend.model import train_model
from backend.eda import delay_by_hour, delay_by_month

st.set_page_config(page_title="Flight Delay Predictor", layout="wide")
st.title("✈️ Flight Delay Prediction System (Placement Portfolio)")

# Load and process dataset
df = load_data("data/flight_data.csv")
df = feature_engineering(df)

# Train model
model, accuracy, feature_cols = train_model(df)

st.metric("Model Accuracy", f"{accuracy*100:.2f}%")

# ================= EDA SECTION =================
st.subheader("📊 Exploratory Data Analysis")

col1, col2 = st.columns(2)

with col1:
    st.pyplot(delay_by_hour(df))

with col2:
    st.pyplot(delay_by_month(df))

# ================= PREDICTION SECTION =================
st.subheader("🔮 Predict Flight Delay")

col1, col2, col3 = st.columns(3)

with col1:
    hour = st.slider("Departure Hour", 0, 23, 10)
    weather = st.selectbox("Weather", ["Clear", "Bad"])

with col2:
    month = st.selectbox("Month", list(range(1, 13)))
    day = st.selectbox("Day of Week (1=Mon, 7=Sun)", list(range(1, 8)))

with col3:
    distance = st.number_input("Distance (km)", min_value=200, max_value=3000, value=900)
    traffic_level = st.selectbox("Traffic Level (1=Low, 3=High)", [1, 2, 3])

weather_val = 0 if weather == "Clear" else 1
season = get_season(month)
is_peak = 1 if 7 <= hour <= 10 or 17 <= hour <= 20 else 0

if st.button("Predict"):

    input_dict = {
        'dep_hour': hour,
        'weather': weather_val,
        'month': month,
        'day_of_week': day,
        'distance': distance,
        'traffic_level': traffic_level,
        'season': season,
        'is_peak_hour': is_peak
    }

    # Add encoded airline & origin columns as 0
    for col in feature_cols:
        if col not in input_dict:
            input_dict[col] = 0

    input_df = pd.DataFrame([input_dict])[feature_cols]

    prediction = model.predict(input_df)[0]
    probability = model.predict_proba(input_df).max()

    if prediction:
        st.error(f"⏱️ Flight Likely Delayed (Confidence: {probability:.2f})")
    else:
        st.success(f"🟢 Flight Likely On Time (Confidence: {probability:.2f})")

# ================= FEATURE IMPORTANCE =================
st.subheader("📈 Feature Importance")

importance = pd.DataFrame({
    "Feature": feature_cols,
    "Importance": model.feature_importances_
}).sort_values(by="Importance", ascending=False)

st.bar_chart(importance.set_index("Feature"))
