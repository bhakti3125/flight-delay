import pandas as pd

def load_data(path):
    df = pd.read_csv(path)
    return df

def get_season(month):
    if month in [12, 1, 2]:
        return 1  # Winter
    elif month in [3, 4, 5]:
        return 2  # Summer
    elif month in [6, 7, 8]:
        return 3  # Monsoon
    else:
        return 4  # Autumn

def feature_engineering(df):
    df['season'] = df['month'].apply(get_season)
    df['is_peak_hour'] = df['dep_hour'].apply(
        lambda x: 1 if 7 <= x <= 10 or 17 <= x <= 20 else 0
    )

    # One-hot encode airline and origin
    df = pd.get_dummies(df, columns=['airline', 'origin'], drop_first=True)

    return df
