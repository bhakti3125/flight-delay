import matplotlib.pyplot as plt
import seaborn as sns

def delay_by_hour(df):
    fig, ax = plt.subplots()
    sns.barplot(x='dep_hour', y='delayed', data=df, ax=ax)
    ax.set_title("Delay Rate by Departure Hour")
    return fig

def delay_by_month(df):
    fig, ax = plt.subplots()
    sns.barplot(x='month', y='delayed', data=df, ax=ax)
    ax.set_title("Delay Rate by Month")
    return fig
